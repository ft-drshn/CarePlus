# CarePlus AI — Flutter

Flutter adaptation of the supplied CarePlus AI HTML demo.

## Included
- Patient registration, token generation and virtual waiting state
- Estimated wait and expected return time
- Doctor dashboard, emergency prioritization, call-next and finish-consultation flow
- Simple online-learning estimate per visit type
- Prescription editor and patient-copy preview
- Demo bills, cash-at-clinic state and simulated UPI/card payments
- Notification log (demo only)
- Clinic QR, demo patients, reset control
- Local persistence using `shared_preferences`
- Responsive layout with mobile bottom navigation and wider-screen section chips

## Run
1. Install Flutter SDK and Android Studio or VS Code.
2. Extract this project.
3. In the project directory run:
   ```bash
   flutter pub get
   flutter run
   ```

## Important production notes
- The app currently uses local device storage, not a shared clinic database. For multi-user operation, connect Firebase/your backend with authentication and role-based access.
- Notification entries are simulated. Integrate an approved SMS/WhatsApp provider via a secure backend.
- Payments are simulated. Integrate a gateway such as Razorpay using its official Flutter SDK and server-side order verification before taking real payments.
- The QR is a demo clinic URI. Replace it with a deployed HTTPS registration URL or app-link/deep-link route.
- Do not use this demo as a clinical decision system without appropriate medical, privacy, security and regulatory review.
