import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CarePlusApp());

const Color brand = Color(0xFF2F6FB0);
const Color headerColor = Color(0xFF46739F);
const Color amber = Color(0xFFFFC000);
const Color ink = Color(0xFF14263D);
const Color muted = Color(0xFF5B6B80);
const Map<String, int> visitTypes = {
  'New patient': 12,
  'Follow-up': 7,
  'Routine check-up': 9,
  'Procedure / injection': 15,
  'Emergency': 14,
};

class Patient {
  Patient({
    required this.id,
    required this.token,
    required this.name,
    required this.phone,
    required this.type,
    required this.sequence,
    required this.joinedAt,
    this.emergency = false,
    this.away = false,
    this.warned = false,
    this.status = 'waiting',
    this.consultStartedAt,
    this.duration,
    this.initialWait = 0,
    this.fee = 300,
    this.paymentStatus = 'due',
    this.paymentMethod = '',
    this.paidAt = '',
    this.diagnosis = '',
    this.medicine1 = '',
    this.medicine2 = '',
    this.medicine3 = '',
    this.advice = '',
    this.prescriptionSent = false,
  });

  String id, token, name, phone, type, status;
  int sequence;
  double joinedAt;
  bool emergency, away, warned, prescriptionSent;
  double? consultStartedAt, duration;
  int initialWait, fee;
  String paymentStatus, paymentMethod, paidAt;
  String diagnosis, medicine1, medicine2, medicine3, advice;

  Map<String, dynamic> toJson() => {
    'id': id, 'token': token, 'name': name, 'phone': phone, 'type': type,
    'sequence': sequence, 'joinedAt': joinedAt, 'emergency': emergency,
    'away': away, 'warned': warned, 'status': status,
    'consultStartedAt': consultStartedAt, 'duration': duration,
    'initialWait': initialWait, 'fee': fee, 'paymentStatus': paymentStatus,
    'paymentMethod': paymentMethod, 'paidAt': paidAt, 'diagnosis': diagnosis,
    'medicine1': medicine1, 'medicine2': medicine2, 'medicine3': medicine3,
    'advice': advice, 'prescriptionSent': prescriptionSent,
  };

  factory Patient.fromJson(Map<String, dynamic> j) => Patient(
    id: j['id'] ?? '', token: j['token'] ?? '', name: j['name'] ?? '',
    phone: j['phone'] ?? '', type: j['type'] ?? 'New patient',
    sequence: j['sequence'] ?? 0, joinedAt: (j['joinedAt'] ?? 0).toDouble(),
    emergency: j['emergency'] ?? false, away: j['away'] ?? false,
    warned: j['warned'] ?? false, status: j['status'] ?? 'waiting',
    consultStartedAt: j['consultStartedAt'] == null ? null : (j['consultStartedAt'] as num).toDouble(),
    duration: j['duration'] == null ? null : (j['duration'] as num).toDouble(),
    initialWait: j['initialWait'] ?? 0, fee: j['fee'] ?? 300,
    paymentStatus: j['paymentStatus'] ?? 'due', paymentMethod: j['paymentMethod'] ?? '',
    paidAt: j['paidAt'] ?? '', diagnosis: j['diagnosis'] ?? '',
    medicine1: j['medicine1'] ?? '', medicine2: j['medicine2'] ?? '',
    medicine3: j['medicine3'] ?? '', advice: j['advice'] ?? '',
    prescriptionSent: j['prescriptionSent'] ?? false,
  );
}

class ClinicMessage {
  ClinicMessage(this.patientName, this.phone, this.channel, this.text, this.time);
  String patientName, phone, channel, text, time;
  Map<String, dynamic> toJson() => {
    'patientName': patientName, 'phone': phone, 'channel': channel, 'text': text, 'time': time,
  };
  factory ClinicMessage.fromJson(Map<String, dynamic> j) => ClinicMessage(
    j['patientName'] ?? '', j['phone'] ?? '', j['channel'] ?? 'WhatsApp',
    j['text'] ?? '', j['time'] ?? '',
  );
}

class CarePlusApp extends StatelessWidget {
  const CarePlusApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'CarePlus AI',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: brand, primary: brand),
      scaffoldBackgroundColor: const Color(0xFFF3F6FA),
      appBarTheme: const AppBarTheme(backgroundColor: headerColor, foregroundColor: Colors.white),
      cardTheme: CardThemeData(
        color: Colors.white, elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFD3DDE9)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        filled: true, fillColor: const Color(0xFFF3F6FA),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
    ),
    home: const ClinicHome(),
  );
}

class ClinicHome extends StatefulWidget {
  const ClinicHome({super.key});
  @override
  State<ClinicHome> createState() => _ClinicHomeState();
}

class _ClinicHomeState extends State<ClinicHome> {
  final tabs = const [
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Patient'),
    NavigationDestination(icon: Icon(Icons.medical_services_outlined), selectedIcon: Icon(Icons.medical_services), label: 'Doctor'),
    NavigationDestination(icon: Icon(Icons.description_outlined), selectedIcon: Icon(Icons.description), label: 'Prescription'),
    NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Payment'),
    NavigationDestination(icon: Icon(Icons.notifications_outlined), selectedIcon: Icon(Icons.notifications), label: 'Messages'),
    NavigationDestination(icon: Icon(Icons.qr_code_2), selectedIcon: Icon(Icons.qr_code_2), label: 'Clinic QR'),
  ];

  final List<Patient> queue = [];
  final List<Patient> completed = [];
  final List<ClinicMessage> messages = [];
  Map<String, double> model = {for (final e in visitTypes.entries) e.key: e.value.toDouble()};
  Map<String, int> learned = {};
  int sequence = 0, tab = 0;
  String channel = 'WhatsApp';
  String? selectedPatientId, rxPatientId, payPatientId;
  String paymentMethod = 'UPI';
  DateTime started = DateTime.now();
  Timer? timer;

  double get clinicMinutes => DateTime.now().difference(started).inSeconds.toDouble();
  String clock(double m) {
    final mins = 9 * 60 + m.round();
    return '${(mins ~/ 60 % 24).toString().padLeft(2, '0')}:${(mins % 60).toString().padLeft(2, '0')}';
  }
  int prediction(Patient p) => (model[p.type] ?? 10).round().clamp(3, 999).toInt();
  Patient? get consulting {
    for (final p in queue) { if (p.status == 'consulting') return p; }
    return null;
  }
  List<Patient> get waiting => queue.where((p) => p.status == 'waiting')
    .toList()..sort((a,b) {
      final em = (b.emergency ? 1 : 0).compareTo(a.emergency ? 1 : 0);
      return em != 0 ? em : a.sequence.compareTo(b.sequence);
    });

  @override
  void initState() {
    super.initState();
    _load();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _checkVirtualWait();
      if (mounted) setState(() {});
    });
  }
  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final raw = prefs.getString('careplus_state');
      if (raw != null) {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        setState(() {
          queue..clear()..addAll((j['queue'] as List).map((x) => Patient.fromJson(x)));
          completed..clear()..addAll((j['completed'] as List).map((x) => Patient.fromJson(x)));
          messages..clear()..addAll((j['messages'] as List).map((x) => ClinicMessage.fromJson(x)));
          sequence = j['sequence'] ?? 0;
          channel = j['channel'] ?? 'WhatsApp';
          selectedPatientId = j['selectedPatientId'];
          rxPatientId = j['rxPatientId']; payPatientId = j['payPatientId'];
          if (j['model'] != null) model = (j['model'] as Map<String, dynamic>).map((k,v) => MapEntry(k, (v as num).toDouble()));
          if (j['learned'] != null) learned = (j['learned'] as Map<String, dynamic>).map((k,v) => MapEntry(k, v as int));
        });
      }
    } catch (_) { /* Invalid old demo data is ignored safely. */ }
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('careplus_state', jsonEncode({
      'queue': queue.map((p) => p.toJson()).toList(),
      'completed': completed.map((p) => p.toJson()).toList(),
      'messages': messages.take(100).map((m) => m.toJson()).toList(),
      'sequence': sequence, 'channel': channel, 'selectedPatientId': selectedPatientId,
      'rxPatientId': rxPatientId, 'payPatientId': payPatientId,
      'model': model, 'learned': learned,
    }));
  }

  void notifyPatient(Patient p, String text) {
    messages.insert(0, ClinicMessage(p.name, p.phone, channel, text, clock(clinicMinutes)));
    if (messages.length > 100) messages.removeLast();
  }

  ({int ahead, int wait}) estimate(Patient p) {
    final w = waiting;
    final idx = w.indexWhere((x) => x.id == p.id);
    if (idx < 0) return (ahead: 0, wait: 0);
    var wait = 0;
    final c = consulting;
    if (c != null) wait += (prediction(c) - (clinicMinutes - (c.consultStartedAt ?? clinicMinutes))).ceil().clamp(1, 999).toInt();
    for (final x in w.take(idx)) { wait += prediction(x); }
    return (ahead: idx + (c == null ? 0 : 1), wait: wait);
  }

  void joinPatient(String name, String phone, String type, bool emergency) {
    sequence++;
    final p = Patient(
      id: 'p$sequence', token: 'T${sequence.toString().padLeft(3, '0')}',
      name: name.trim(), phone: phone.trim(), type: emergency ? 'Emergency' : type,
      sequence: sequence, joinedAt: clinicMinutes, emergency: emergency,
    );
    queue.add(p);
    p.initialWait = estimate(p).wait;
    notifyPatient(p, 'Hi ${p.name}, your token is ${p.token}. Estimated wait ~${p.initialWait} min. You can step away — we will message you.');
    selectedPatientId = p.id;
    if (emergency) {
      for (final x in waiting.where((x) => x.id != p.id && x.away)) {
        final a = estimate(x);
        notifyPatient(x, 'Queue update: an emergency case was added. New wait is ~${a.wait} min; expected time ${clock(clinicMinutes + a.wait)}.');
      }
    }
    save();
    setState(() {});
  }

  void callNext() {
    if (consulting != null || waiting.isEmpty) return;
    final p = waiting.first;
    p.status = 'consulting'; p.consultStartedAt = clinicMinutes;
    notifyPatient(p, '${p.name}, the doctor is ready for you now. Please come in (${p.token}).');
    rxPatientId = p.id;
    save(); setState(() {});
  }

  void finishConsultation() {
    final p = consulting;
    if (p == null) return;
    p.duration = (clinicMinutes - (p.consultStartedAt ?? clinicMinutes)).clamp(1, 999999).toDouble();
    p.status = 'done';
    queue.removeWhere((x) => x.id == p.id);
    completed.add(p);
    model[p.type] = (model[p.type] ?? 10) * .7 + p.duration! * .3;
    learned[p.type] = (learned[p.type] ?? 0) + 1;
    rxPatientId = p.id; payPatientId = p.id;
    save(); setState(() {});
  }

  void _checkVirtualWait() {
    var changed = false;
    for (final p in waiting) {
      final a = estimate(p);
      if (p.away && !p.warned && a.ahead <= 2) {
        p.warned = true;
        notifyPatient(p, 'Your turn is near — ${a.ahead} ahead of you (~${a.wait} min). Please return to the clinic now and check in.');
        changed = true;
      }
    }
    if (changed) save();
  }

  void addDemoPatients() {
    joinPatient('Asha Patil', '9800000001', 'New patient', false);
    joinPatient('Ravi Shinde', '9800000002', 'Follow-up', false);
    joinPatient('Meena Jadhav', '9800000003', 'Routine check-up', false);
    joinPatient('Sunil More', '9800000004', 'Procedure / injection', false);
    setState(() { tab = 1; selectedPatientId = null; });
    save();
  }

  Future<void> resetData() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Reset all data?'),
      content: const Text('This clears the queue, messages, completed consultations, and learned estimates.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Reset')),
      ],
    ));
    if (ok != true) return;
    setState(() {
      queue.clear(); completed.clear(); messages.clear(); sequence = 0;
      model = {for (final e in visitTypes.entries) e.key: e.value.toDouble()};
      learned.clear(); selectedPatientId = null; rxPatientId = null; payPatientId = null;
      tab = 5; started = DateTime.now();
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('careplus_state');
  }

  Patient? findPatient(String? id, {bool includeQueue = true}) {
    if (id == null) return null;
    for (final p in [...(includeQueue ? queue : <Patient>[]), ...completed]) {
      if (p.id == id) return p;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final labels = ['Patient', 'Doctor dashboard', 'Prescription', 'Payment', 'Notifications', 'Clinic QR'];
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('CarePlus AI', style: TextStyle(fontFamily: 'Georgia', fontWeight: FontWeight.bold)),
          Text('Don’t wait in the queue. Know when to come.', style: TextStyle(fontSize: 12, fontWeight: FontWeight.normal)),
        ]),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 880),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (MediaQuery.sizeOf(context).width > 650)
                  Padding(padding: const EdgeInsets.only(bottom: 12), child: Wrap(spacing: 8, children: List.generate(labels.length, (i) =>
                    ChoiceChip(label: Text(labels[i]), selected: tab == i, onSelected: (_) => setState(() => tab = i)))),
                  ),
                if (tab == 0) patientView(),
                if (tab == 1) doctorView(),
                if (tab == 2) prescriptionView(),
                if (tab == 3) paymentView(),
                if (tab == 4) notificationsView(),
                if (tab == 5) qrView(),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, destinations: tabs, onDestinationSelected: (i) => setState(() => tab = i)),
    );
  }

  Widget panel(Widget child) => Card(
    margin: const EdgeInsets.only(bottom: 14),
    child: Padding(padding: const EdgeInsets.all(16), child: child),
  );
  Widget sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Georgia')),
  );
  Widget fieldLabel(String s) => Padding(
    padding: const EdgeInsets.only(top: 10, bottom: 4),
    child: Text(s, style: const TextStyle(fontSize: 13, color: muted)),
  );
  Widget stat(String label, String value) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(border: Border.all(color: const Color(0xFFD3DDE9)), borderRadius: BorderRadius.circular(10)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 3),
      Text(value, style: const TextStyle(fontFamily: 'Georgia', fontSize: 22, fontWeight: FontWeight.bold)),
    ]),
  );
  Widget stats(List<Widget> children) => Wrap(spacing: 10, runSpacing: 10, children: children.map((w) => SizedBox(width: 155, child: w)).toList());
  Widget statusChip(Patient p) {
    final label = p.status == 'consulting' ? 'In consultation' : p.emergency ? 'Emergency' : 'Waiting';
    final color = p.status == 'consulting' ? Colors.orange : p.emergency ? Colors.red : brand;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(.4))),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
    );
  }

  Widget patientView() {
    final active = queue;
    final selected = findPatient(selectedPatientId);
    if (selected == null) {
      return panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Get your clinic token'),
        const Text('Register for a visit and track your estimated waiting time.'),
        PatientRegistration(onSubmit: joinPatient),
        if (active.isNotEmpty) ...[
          fieldLabel('Viewing existing patient'),
          DropdownButtonFormField<String>(
            value: selectedPatientId,
            isExpanded: true,
            decoration: const InputDecoration(),
            items: [const DropdownMenuItem(value: null, child: Text('New patient…')), ...active.map((p) => DropdownMenuItem(value: p.id, child: Text('${p.token} – ${p.name}')))],
            onChanged: (v) => setState(() => selectedPatientId = v),
          ),
        ],
      ]));
    }
    if (selected.status == 'done') return panel(const Text('This visit is completed. You can view its prescription and payment in their respective tabs.'));
    final a = estimate(selected);
    return Column(children: [
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        fieldLabel('Viewing as'),
        DropdownButtonFormField<String>(
          value: selected.id, isExpanded: true, decoration: const InputDecoration(),
          items: active.map((p) => DropdownMenuItem(value: p.id, child: Text('${p.token} – ${p.name}'))).toList(),
          onChanged: (v) => setState(() => selectedPatientId = v),
        ),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(selected.token, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: brand, fontFamily: 'Georgia')),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(selected.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 4), statusChip(selected), Text(selected.type, style: const TextStyle(color: muted, fontSize: 12)),
          ])),
        ]),
        if (selected.status == 'consulting')
          const Padding(padding: EdgeInsets.only(top: 18), child: Text('It’s your turn — please go in.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)))
        else ...[
          const SizedBox(height: 18),
          stats([
            stat('Estimated wait', '~${a.wait} min'),
            stat('Come back at', clock(clinicMinutes + a.wait)),
            stat('Patients ahead', '${a.ahead}'),
          ]),
          const SizedBox(height: 12),
          LinearProgressIndicator(value: (1 - a.wait / (selected.initialWait > a.wait ? selected.initialWait.toDouble() : (a.wait == 0 ? 1 : a.wait))).clamp(.04, 1).toDouble(), minHeight: 8, backgroundColor: const Color(0xFFD3DDE9), color: amber),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () { setState(() { selected.away = !selected.away; selected.warned = false; if (selected.away) notifyPatient(selected, 'You are now waiting virtually. Expected return time ${clock(clinicMinutes + a.wait)}.'); }); save(); },
            icon: Icon(selected.away ? Icons.location_on : Icons.directions_walk),
            label: Text(selected.away ? 'I’m back at the clinic' : 'Step away (virtual waiting)'),
            style: FilledButton.styleFrom(backgroundColor: selected.away ? brand : amber, foregroundColor: selected.away ? Colors.white : ink),
          ),
          const SizedBox(height: 8),
          Text(selected.away ? 'You are waiting virtually. A message appears here when your turn is near.' : 'The estimate updates as the queue changes.', style: const TextStyle(color: muted, fontSize: 12)),
        ],
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Messages to your phone'),
        ...messages.where((m) => m.patientName == selected.name).map(messageTile),
        if (messages.every((m) => m.patientName != selected.name)) const Text('No messages yet.', style: TextStyle(color: muted)),
      ])),
    ]);
  }

  Widget doctorView() {
    final w = waiting;
    final c = consulting;
    final avg = completed.isEmpty ? '–' : '${(completed.fold<double>(0, (s,p) => s + (p.duration ?? 0)) / completed.length).round()} min';
    return Column(children: [
      panel(Wrap(spacing: 10, runSpacing: 10, children: [
        SizedBox(width: 150, child: stat('Waiting', '${w.length}')),
        SizedBox(width: 150, child: stat('Served today', '${completed.length}')),
        SizedBox(width: 150, child: stat('Avg consult', avg)),
        SizedBox(width: 150, child: stat('Clinic time', clock(clinicMinutes))),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Now consulting'),
        if (c != null)
          Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, spacing: 10, runSpacing: 10, children: [
            Text(c.token, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: brand, fontFamily: 'Georgia')),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)), statusChip(c),
              Text('${c.type} · ${(clinicMinutes - (c.consultStartedAt ?? clinicMinutes)).round()} of ~${prediction(c)} min', style: const TextStyle(fontSize: 12, color: muted)),
            ]),
            FilledButton(onPressed: finishConsultation, style: FilledButton.styleFrom(backgroundColor: amber, foregroundColor: ink), child: const Text('Finish consultation')),
          ])
        else
          Wrap(spacing: 10, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
            const Text('No one in consultation.', style: TextStyle(color: muted)),
            FilledButton(onPressed: w.isEmpty ? null : callNext, child: const Text('Call next patient')),
          ]),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: sectionTitle('Queue')),
          FilledButton.icon(onPressed: () { joinPatient('Walk-in emergency', '', 'Emergency', true); setState(() => tab = 1); }, icon: const Icon(Icons.add), label: const Text('Emergency walk-in')),
        ]),
        if (w.isEmpty) const Text('The queue is empty.', style: TextStyle(color: muted)),
        ...w.map((p) => Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: const BoxDecoration(border: Border(top: BorderSide(color: Color(0xFFD3DDE9)))),
          child: Wrap(spacing: 8, runSpacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
            SizedBox(width: 58, child: Text(p.token, style: const TextStyle(fontSize: 19, color: brand, fontWeight: FontWeight.bold))),
            SizedBox(width: 180, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)), statusChip(p),
              if (p.away) const Text('Away', style: TextStyle(color: Colors.green, fontSize: 12)),
              Text('${p.type} · est. ${estimate(p).wait} min', style: const TextStyle(color: muted, fontSize: 12)),
            ])),
            if (!p.emergency) OutlinedButton(onPressed: () {
              setState(() {
                p.emergency = true;
                for (final x in waiting.where((x) => x.id != p.id && x.away)) {
                  final a = estimate(x); notifyPatient(x, 'Queue recalculated for an emergency. New wait ~${a.wait} min.');
                }
              }); save();
            }, child: const Text('Mark emergency')),
          ]),
        )),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('What the AI model has learned'),
        const Text('Estimated minutes per visit type. Each finished consultation updates the estimate.', style: TextStyle(color: muted, fontSize: 12)),
        ...visitTypes.keys.map((type) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(children: [
            Expanded(child: Text(type)),
            Text('${model[type]!.round()} min  (${learned[type] ?? 0} learned)', style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
        )),
      ])),
    ]);
  }

  Widget prescriptionView() {
    final people = [...queue.where((p) => p.status == 'consulting'), ...completed];
    if (people.isEmpty) return panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sectionTitle('Prescription'),
      const Text('No consultations yet. Call a patient from the Doctor dashboard, then write the prescription here.', style: TextStyle(color: muted)),
    ]));
    final p = findPatient(rxPatientId, includeQueue: true) != null && people.any((x) => x.id == rxPatientId)
      ? people.firstWhere((x) => x.id == rxPatientId) : people.last;
    rxPatientId = p.id;
    return Column(children: [
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        fieldLabel('Patient'),
        DropdownButtonFormField<String>(
          value: p.id, isExpanded: true,
          items: people.map((x) => DropdownMenuItem(value: x.id, child: Text('${x.token} – ${x.name}${x.status == 'consulting' ? ' (in consultation)' : ''}'))).toList(),
          onChanged: (v) => setState(() => rxPatientId = v),
        ),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Write prescription'),
        Text('${p.name} · ${p.token} · ${p.type}', style: const TextStyle(color: muted, fontSize: 12)),
        fieldLabel('Diagnosis'),
        TextFormField(key: ValueKey('${p.id}-dx'), initialValue: p.diagnosis, onChanged: (v) { p.diagnosis = v; save(); }),
        for (final item in [
          ('Medicine 1 (name, dose, days)', p.medicine1, (String v) => p.medicine1 = v),
          ('Medicine 2 (name, dose, days)', p.medicine2, (String v) => p.medicine2 = v),
          ('Medicine 3 (name, dose, days)', p.medicine3, (String v) => p.medicine3 = v),
          ('Advice', p.advice, (String v) => p.advice = v),
        ]) ...[
          fieldLabel(item.$1),
          TextFormField(key: ValueKey('${p.id}-${item.$1}'), initialValue: item.$2, onChanged: (v) { item.$3(v); save(); }),
        ],
        const SizedBox(height: 14),
        FilledButton.icon(onPressed: () {
          setState(() => p.prescriptionSent = true);
          notifyPatient(p, 'Your prescription is ready${p.diagnosis.isEmpty ? '' : ' (${p.diagnosis})'}. Open the Prescription page to view it.');
          save();
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Prescription prepared in this demo.')));
        }, icon: const Icon(Icons.send), label: Text(p.prescriptionSent ? 'Send again' : 'Send to patient')),
      ])),
      if (p.prescriptionSent) panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Patient copy'),
        Text('${p.name} · ${p.token} · ${clock(p.consultStartedAt ?? 0)}', style: const TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 8), Text('Diagnosis: ${p.diagnosis.isEmpty ? '–' : p.diagnosis}'),
        const SizedBox(height: 8), const Text('Medicines', style: TextStyle(fontWeight: FontWeight.bold)),
        for (final med in [p.medicine1, p.medicine2, p.medicine3].where((x) => x.trim().isNotEmpty)) Text('• $med'),
        if ([p.medicine1, p.medicine2, p.medicine3].every((x) => x.trim().isEmpty)) const Text('• None prescribed'),
        const SizedBox(height: 8), Text('Advice: ${p.advice.isEmpty ? '–' : p.advice}'),
      ])),
    ]);
  }

  Widget paymentView() {
    if (completed.isEmpty) return panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sectionTitle('Payment'), const Text('No bills yet. A bill appears here after the doctor finishes a consultation.', style: TextStyle(color: muted)),
    ]));
    final p = completed.firstWhere((x) => x.id == payPatientId, orElse: () => completed.last);
    payPatientId = p.id;
    final collected = completed.where((x) => x.paymentStatus == 'paid').fold<int>(0, (s,x) => s + x.fee);
    final pending = completed.where((x) => x.paymentStatus != 'paid').fold<int>(0, (s,x) => s + x.fee);
    return Column(children: [
      panel(stats([stat('Collected', '₹$collected'), stat('Pending', '₹$pending')])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        fieldLabel('Bill for'),
        DropdownButtonFormField<String>(
          value: p.id, isExpanded: true,
          items: completed.map((x) => DropdownMenuItem(value: x.id, child: Text('${x.token} – ${x.name} · ₹${x.fee}${x.paymentStatus == 'paid' ? ' (paid)' : ''}'))).toList(),
          onChanged: (v) => setState(() => payPatientId = v),
        ),
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('Bill summary'),
        Row(children: [Expanded(child: Text('Consultation (${p.type})')), Text('₹${p.fee}', style: const TextStyle(fontWeight: FontWeight.bold))]),
        const Divider(height: 24),
        Row(children: [const Expanded(child: Text('Total', style: TextStyle(fontWeight: FontWeight.bold))), Text('₹${p.fee}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Georgia'))]),
        const SizedBox(height: 12),
        if (p.paymentStatus == 'paid')
          Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.green.withOpacity(.08), borderRadius: BorderRadius.circular(8)), child: Text('Paid ₹${p.fee} via ${p.paymentMethod}\\nReceipt R-${p.token} · ${p.paidAt}'))
        else if (p.paymentStatus == 'cash')
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Please pay at the reception.'),
            FilledButton(onPressed: () {
              setState(() { p.paymentStatus = 'paid'; p.paymentMethod = 'Cash'; p.paidAt = clock(clinicMinutes); });
              notifyPatient(p, 'Cash payment of ₹${p.fee} received. Receipt R-${p.token}. Thank you!'); save();
            }, child: const Text('Mark cash received')),
          ])
        else ...[
          fieldLabel('Consultation fee (₹)'),
          TextFormField(initialValue: '${p.fee}', keyboardType: TextInputType.number, onChanged: (v) { p.fee = (int.tryParse(v) ?? 0).clamp(0, 100000000).toInt(); save(); setState(() {}); }),
          fieldLabel('Payment method'),
          DropdownButtonFormField<String>(
            value: paymentMethod,
            items: const ['UPI', 'Card', 'Cash at clinic'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
            onChanged: (v) => setState(() => paymentMethod = v ?? 'UPI'),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: () {
            setState(() {
              if (paymentMethod == 'Cash at clinic') { p.paymentStatus = 'cash'; p.paymentMethod = 'Cash'; }
              else { p.paymentStatus = 'paid'; p.paymentMethod = paymentMethod; p.paidAt = clock(clinicMinutes); }
            });
            notifyPatient(p, p.paymentStatus == 'cash' ? 'Please pay ₹${p.fee} in cash at the reception.' : 'Payment of ₹${p.fee} received via ${p.paymentMethod}. Receipt R-${p.token}. Get well soon!');
            save();
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(p.paymentStatus == 'cash' ? 'Cash payment marked as due at reception.' : 'Demo payment recorded. No real money was transferred.')));
          }, child: Text(paymentMethod == 'Cash at clinic' ? 'Continue with cash' : 'Pay ₹${p.fee}')),
          const SizedBox(height: 6),
          const Text('Demo payment only: no real money moves. Connect a payment gateway for live payments.', style: TextStyle(color: muted, fontSize: 12)),
        ],
      ])),
      panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        sectionTitle('All bills'),
        ...completed.reversed.map((x) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text('${x.token} · ${x.name}'),
          subtitle: Text(x.paymentStatus == 'paid' ? 'Paid via ${x.paymentMethod}' : x.paymentStatus == 'cash' ? 'Will pay cash at reception' : 'Awaiting payment'),
          trailing: Text('₹${x.fee}'),
          leading: Icon(x.paymentStatus == 'paid' ? Icons.check_circle : Icons.receipt_long, color: x.paymentStatus == 'paid' ? Colors.green : brand),
          onTap: () => setState(() => payPatientId = x.id),
        )),
      ])),
    ]);
  }

  Widget messageTile(ClinicMessage m) => Container(
    width: double.infinity, margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: const Color(0xFFF3F6FA), borderRadius: BorderRadius.circular(8), border: const Border(left: BorderSide(color: brand, width: 4))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('${m.channel} · ${m.time}', style: const TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 3), Text(m.text),
    ]),
  );

  Widget notificationsView() => Column(children: [
    panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sectionTitle('Notification log'),
      fieldLabel('Send through'),
      DropdownButtonFormField<String>(
        value: channel, items: const ['WhatsApp', 'SMS'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
        onChanged: (v) { setState(() => channel = v ?? 'WhatsApp'); save(); },
      ),
      const SizedBox(height: 8),
      const Text('Demo mode: messages appear here. Live SMS/WhatsApp delivery requires a backend and provider integration.', style: TextStyle(color: muted, fontSize: 12)),
    ])),
    panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sectionTitle('Messages'),
      if (messages.isEmpty) const Text('Nothing sent yet.', style: TextStyle(color: muted)),
      ...messages.map((m) => messageTile(m)),
    ])),
  ]);

  Widget qrView() => Column(children: [
    panel(Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
      sectionTitle('Clinic QR code'),
      const SizedBox(height: 8),
      QrImageView(
        data: 'careplus://clinic/register',
        version: QrVersions.auto,
        size: 190,
        backgroundColor: Colors.white,
        semanticsLabel: 'CarePlus clinic registration QR code',
      ),
      const SizedBox(height: 10),
      const Text('Print this code for the reception. In this demo, the QR represents the clinic registration link; scanning it does not automatically open this local app.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 16),
      Wrap(spacing: 10, runSpacing: 10, alignment: WrapAlignment.center, children: [
        FilledButton.icon(onPressed: addDemoPatients, icon: const Icon(Icons.group_add), label: const Text('Add 4 demo patients')),
        OutlinedButton.icon(onPressed: resetData, icon: const Icon(Icons.delete_outline), label: const Text('Reset all data')),
      ]),
    ])),
    panel(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      sectionTitle('Demo status'),
      Text('${queue.length} active patients · ${completed.length} completed visits · ${messages.length} messages'),
    ])),
  ]);
}

class PatientRegistration extends StatefulWidget {
  const PatientRegistration({super.key, required this.onSubmit});
  final void Function(String name, String phone, String type, bool emergency) onSubmit;
  @override
  State<PatientRegistration> createState() => _PatientRegistrationState();
}
class _PatientRegistrationState extends State<PatientRegistration> {
  final name = TextEditingController(), phone = TextEditingController();
  String type = 'New patient';
  bool emergency = false;
  final formKey = GlobalKey<FormState>();
  @override
  void dispose() { name.dispose(); phone.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Form(
    key: formKey,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(padding: const EdgeInsets.only(top: 10, bottom: 4), child: const Text('Your name', style: TextStyle(fontSize: 13, color: muted))),
      TextFormField(controller: name, decoration: const InputDecoration(hintText: 'Enter full name'), validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter your name' : null),
      const Padding(padding: EdgeInsets.only(top: 10, bottom: 4), child: Text('Mobile number', style: TextStyle(fontSize: 13, color: muted))),
      TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: '98XXXXXXXX')),
      const Padding(padding: EdgeInsets.only(top: 10, bottom: 4), child: Text('Reason for visit', style: TextStyle(fontSize: 13, color: muted))),
      DropdownButtonFormField<String>(
        value: type,
        items: visitTypes.keys.where((x) => x != 'Emergency').map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
        onChanged: (v) => setState(() => type = v ?? 'New patient'),
      ),
      CheckboxListTile(
        contentPadding: EdgeInsets.zero, value: emergency, onChanged: (v) => setState(() => emergency = v ?? false),
        title: const Text('This is an emergency'), controlAffinity: ListTileControlAffinity.leading,
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        onPressed: () {
          if (!formKey.currentState!.validate()) return;
          widget.onSubmit(name.text, phone.text, type, emergency);
          name.clear(); phone.clear(); setState(() { emergency = false; type = 'New patient'; });
        },
        icon: const Icon(Icons.confirmation_number_outlined), label: const Text('Get my token'),
      ),
    ]),
  );
}
